# [ALL IN ONΞ™](https://tinyurl.com/3jvb65tv)
***
## [YouTube](https://tinyurl.com/3jvb65tv )
***
### [Support Server](https://discord.gg/ndfEefv9aw)
***
your config in **`config.def`** file